﻿#include <cstdint>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <random>
#include <vector>
#include <cuda_runtime.h>
#include <curand_kernel.h>

#define ROTL(a,b) (((a) << (b)) | ((a) >> (32 - (b))))
#define QR(a, b, c, d) (                    \
        a += b,  d ^= a,  d = ROTL(d,16),   \
        c += d,  b ^= c,  b = ROTL(b,12),   \
        a += b,  d ^= a,  d = ROTL(d, 8),   \
        c += d,  b ^= c,  b = ROTL(b, 7))


#define CUDA_CHECK(call)                                                       \
    do {                                                                       \
        cudaError_t _e = (call);                                               \
        if (_e != cudaSuccess) {                                               \
            fprintf(stderr, "CUDA error %s:%d: %s\n", __FILE__, __LINE__,      \
                    cudaGetErrorString(_e));                                   \
            exit(EXIT_FAILURE);                                                \
        }                                                                      \
    } while (0)

#define THREADS_PER_BLOCK 256


__device__ __forceinline__ int evalSample(const uint32_t base[12],
    uint32_t iv0, uint32_t iv1,
    uint32_t iv2, uint32_t iv3)
{
    uint32_t X[16];
#pragma unroll
    for (int i = 0; i < 12; ++i) X[i] = base[i];
    X[12] = iv0; X[13] = iv1; X[14] = iv2; X[15] = iv3;

    int input = 0;
    int output = 0;

    QR(X[0], X[4], X[8], X[12]);
    QR(X[1], X[5], X[9], X[13]);
    QR(X[2], X[6], X[10], X[14]);
    QR(X[3], X[7], X[11], X[15]);

    QR(X[0], X[5], X[10], X[15]);
    QR(X[1], X[6], X[11], X[12]);
    QR(X[2], X[7], X[8], X[13]);
    QR(X[3], X[4], X[9], X[14]);

    QR(X[0], X[4], X[8], X[12]);
    QR(X[1], X[5], X[9], X[13]);
    QR(X[2], X[6], X[10], X[14]);
    QR(X[3], X[7], X[11], X[15]);

    QR(X[0], X[5], X[10], X[15]);
    QR(X[1], X[6], X[11], X[12]);
    QR(X[2], X[7], X[8], X[13]);
    QR(X[3], X[4], X[9], X[14]);

    QR(X[0], X[4], X[8], X[12]);
    QR(X[1], X[5], X[9], X[13]);
    QR(X[2], X[6], X[10], X[14]);
    QR(X[3], X[7], X[11], X[15]);

    input = (X[2] >> 0) & 0x1 ^
        (X[6] >> 7) & 0x1 ^ (X[6] >> 19) & 0x1 ^
        (X[10] >> 12) & 0x1 ^
        (X[14] >> 0) & 0x1;

   
    QR(X[0], X[5], X[10], X[15]);
    QR(X[1], X[6], X[11], X[12]);
    QR(X[2], X[7], X[8], X[13]);
    QR(X[3], X[4], X[9], X[14]);

    QR(X[0], X[4], X[8], X[12]);
    QR(X[1], X[5], X[9], X[13]);
    QR(X[2], X[6], X[10], X[14]);
    QR(X[3], X[7], X[11], X[15]);

    output = (X[0] >> 23) & 0x1 ^ (X[0] >> 19) & 0x1 ^ (X[0] >> 18) & 0x1 ^ (X[0] >> 7) & 0x1 ^ (X[0] >> 3) & 0x1 ^ (X[0] >> 2) & 0x1 ^
        (X[1] >> 16) & 0x1 ^
        (X[2] >> 24) & 0x1 ^ (X[2] >> 12) & 0x1 ^ (X[2] >> 11) & 0x1 ^ (X[2] >> 8) & 0x1 ^ (X[2] >> 0) & 0x1 ^
        (X[3] >> 31) & 0x1 ^ (X[3] >> 30) & 0x1 ^ (X[3] >> 28) & 0x1 ^ (X[3] >> 20) & 0x1 ^ (X[3] >> 16) & 0x1 ^ (X[3] >> 15) & 0x1 ^ (X[3] >> 12) & 0x1 ^ (X[3] >> 7) & 0x1 ^ (X[3] >> 4) & 0x1 ^ (X[3] >> 0) & 0x1 ^
        (X[4] >> 31) & 0x1 ^ (X[4] >> 30) & 0x1 ^ (X[4] >> 25) & 0x1 ^ (X[4] >> 19) & 0x1 ^ (X[4] >> 14) & 0x1 ^
        (X[5] >> 7) & 0x1 ^
        (X[6] >> 31) & 0x1 ^ (X[6] >> 25) & 0x1 ^ (X[6] >> 19) & 0x1 ^ (X[6] >> 13) & 0x1 ^ (X[6] >> 7) & 0x1 ^
        (X[7] >> 27) & 0x1 ^ (X[7] >> 26) & 0x1 ^ (X[7] >> 23) & 0x1 ^ (X[7] >> 22) & 0x1 ^ (X[7] >> 7) & 0x1 ^ (X[7] >> 6) & 0x1 ^ (X[7] >> 3) & 0x1 ^
        (X[8] >> 24) & 0x1 ^ (X[8] >> 23) & 0x1 ^ (X[8] >> 18) & 0x1 ^ (X[8] >> 12) & 0x1 ^
        (X[10] >> 26) & 0x1 ^ (X[10] >> 24) & 0x1 ^ (X[10] >> 18) & 0x1 ^
        (X[11] >> 28) & 0x1 ^ (X[11] >> 20) & 0x1 ^ (X[11] >> 15) & 0x1 ^
        (X[12] >> 31) & 0x1 ^ (X[12] >> 20) & 0x1 ^ (X[12] >> 11) & 0x1 ^ (X[12] >> 10) & 0x1 ^ (X[12] >> 7) & 0x1 ^
        (X[13] >> 24) & 0x1 ^ (X[13] >> 8) & 0x1 ^ (X[13] >> 0) & 0x1 ^
        (X[14] >> 26) & 0x1 ^ (X[14] >> 20) & 0x1 ^ (X[14] >> 19) & 0x1 ^ (X[14] >> 16) & 0x1 ^ (X[14] >> 12) & 0x1 ^ (X[14] >> 6) & 0x1 ^ (X[14] >> 0) & 0x1 ^
        (X[15] >> 31) & 0x1 ^ (X[15] >> 19) & 0x1 ^ (X[15] >> 16) & 0x1 ^ (X[15] >> 15) & 0x1 ^ (X[15] >> 12) & 0x1 ^ (X[15] >> 7) & 0x1 ^ (X[15] >> 6) & 0x1 ^ (X[15] >> 4) & 0x1 ^ (X[15] >> 0) & 0x1 ^

        ((((X[0] >> 18) & 0x1) ^ 0x1) & (((X[4] >> 25) & 0x1) ^ ((X[8] >> 18) & 0x1))) ^
        (((((X[0] >> 18) & 0x1) ^ ((X[4] >> 25) & 0x1) ^ ((X[8] >> 18) & 0x1)) & (((X[0] >> 17) & 0x1) ^ 0x1) & (((X[4] >> 24) & 0x1) ^ ((X[8] >> 17) & 0x1)))) ^

        ((((X[0] >> 11) & 0x1) ^ 0x1) & (((X[4] >> 18) & 0x1) ^ ((X[8] >> 11) & 0x1))) ^
        (((((X[0] >> 11) & 0x1) ^ ((X[4] >> 18) & 0x1) ^ ((X[8] >> 11) & 0x1) ^ 0x1) & (((X[0] >> 10) & 0x1) ^ 0x1) & (((X[4] >> 17) & 0x1) ^ ((X[8] >> 10) & 0x1)))) ^

        ((((X[0] >> 6) & 0x1) ^ 0x1) & (((X[4] >> 13) & 0x1) ^ ((X[8] >> 6) & 0x1))) ^
        (((((X[0] >> 6) & 0x1) ^ ((X[4] >> 13) & 0x1) ^ ((X[8] >> 6) & 0x1) ^ 0x1) & (((X[0] >> 5) & 0x1) ^ 0x1) & (((X[4] >> 12) & 0x1) ^ ((X[8] >> 5) & 0x1)))) ^

        ((((X[8] >> 6) & 0x1) ^ 0x1) & ((X[12] >> 6) & 0x1)) ^
        (((((X[8] >> 6) & 0x1) ^ ((X[12] >> 6) & 0x1) ^ 0x1) & (((X[8] >> 5) & 0x1) ^ 0x1) & ((X[12] >> 5) & 0x1))) ^

        ((((X[2] >> 23) & 0x1) ^ 0x1) & (((X[6] >> 30) & 0x1) ^ ((X[10] >> 23) & 0x1))) ^
        (((((X[2] >> 23) & 0x1) ^ ((X[6] >> 30) & 0x1) ^ ((X[10] >> 23) & 0x1) ^ 0x1) & (((X[2] >> 22) & 0x1) ^ 0x1) & (((X[6] >> 29) & 0x1) ^ ((X[10] >> 22) & 0x1)))) ^

        ((((X[10] >> 25) & 0x1) ^ 0x1) & ((X[14] >> 25) & 0x1)) ^
        (((((X[10] >> 25) & 0x1) ^ ((X[14] >> 25) & 0x1) ^ 0x1) & (((X[10] >> 24) & 0x1) ^ 0x1) & ((X[14] >> 24) & 0x1))) ^

        ((((X[10] >> 11) & 0x1) ^ 0x1) & ((X[14] >> 11) & 0x1)) ^
        (((((X[10] >> 11) & 0x1) ^ ((X[14] >> 11) & 0x1) ^ 0x1) & (((X[10] >> 10) & 0x1) ^ 0x1) & ((X[14] >> 10) & 0x1))) ^

        ((((X[10] >> 5) & 0x1) ^ 0x1) & ((X[14] >> 5) & 0x1)) ^
        (((((X[10] >> 5) & 0x1) ^ ((X[14] >> 5) & 0x1) ^ 0x1) & (((X[10] >> 4) & 0x1) ^ 0x1) & ((X[14] >> 4) & 0x1))) ^

        ((((X[3] >> 19) & 0x1) ^ 0x1) & (((X[7] >> 26) & 0x1) ^ ((X[11] >> 19) & 0x1))) ^
        (((((X[3] >> 19) & 0x1) ^ ((X[7] >> 26) & 0x1) ^ ((X[11] >> 19) & 0x1) ^ 0x1) & (((X[3] >> 18) & 0x1) ^ 0x1) & (((X[7] >> 25) & 0x1) ^ ((X[11] >> 18) & 0x1)))) ^

        ((((X[3] >> 15) & 0x1) ^ 0x1) & (((X[7] >> 22) & 0x1) ^ ((X[11] >> 15) & 0x1))) ^
        (((((X[3] >> 15) & 0x1) ^ ((X[7] >> 22) & 0x1) ^ ((X[11] >> 15) & 0x1)) & (((X[3] >> 14) & 0x1) ^ 0x1) & (((X[7] >> 21) & 0x1) ^ ((X[11] >> 14) & 0x1)))) ^

        ((((X[3] >> 11) & 0x1) ^ 0x1) & (((X[7] >> 18) & 0x1) ^ ((X[11] >> 11) & 0x1))) ^
        (((((X[3] >> 11) & 0x1) ^ ((X[7] >> 18) & 0x1) ^ ((X[11] >> 11) & 0x1) ^ 0x1) & (((X[3] >> 10) & 0x1) ^ 0x1) & (((X[7] >> 17) & 0x1) ^ ((X[11] >> 10) & 0x1)))) ^

        ((((X[11] >> 30) & 0x1) ^ 0x1) & ((X[15] >> 30) & 0x1)) ^
        (((((X[11] >> 30) & 0x1) ^ ((X[15] >> 30) & 0x1) ^ 0x1) & (((X[11] >> 29) & 0x1) ^ 0x1) & ((X[15] >> 29) & 0x1))) ^

        ((((X[11] >> 18) & 0x1) ^ 0x1) & ((X[15] >> 18) & 0x1)) ^
        (((((X[11] >> 18) & 0x1) ^ ((X[15] >> 18) & 0x1) ^ 0x1) & (((X[11] >> 17) & 0x1) ^ 0x1) & ((X[15] >> 17) & 0x1))) ^

        ((((X[11] >> 15) & 0x1) ^ 0x1) & ((X[15] >> 15) & 0x1)) ^
        (((((X[11] >> 15) & 0x1) ^ ((X[15] >> 15) & 0x1) ^ 0x1) & (((X[11] >> 14) & 0x1) ^ 0x1) & ((X[15] >> 14) & 0x1)));

    return (input == output) ? 1 : 0;
}


__global__ void countMatchesKernel(const uint32_t* __restrict__ base, // 12 words
    uint64_t ivsPerThread,
    unsigned long long seed,
    unsigned long long* __restrict__ globalCount)
{
    __shared__ unsigned long long sdata[THREADS_PER_BLOCK];

    const unsigned int tid = threadIdx.x;
    const unsigned int gid = blockIdx.x * blockDim.x + threadIdx.x;

   
    uint32_t localBase[12];
#pragma unroll
    for (int i = 0; i < 12; ++i) localBase[i] = base[i];

 
    curandStatePhilox4_32_10_t st;
    curand_init(seed, gid, 0, &st);

    unsigned long long local = 0;
    for (uint64_t k = 0; k < ivsPerThread; ++k) {
        uint4 r = curand4(&st); 
        local += (unsigned long long)evalSample(localBase, r.x, r.y, r.z, r.w);
    }

    sdata[tid] = local;
    __syncthreads();

  
    for (unsigned int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (tid < s) sdata[tid] += sdata[tid + s];
        __syncthreads();
    }

    if (tid == 0) atomicAdd(globalCount, sdata[0]);
}

static double GetAverageABS(const double* array, uint64_t NS) {
    double sum = 0.0;
    for (uint64_t i = 0; i < NS; ++i) sum += fabs(array[i]);
    return sum / (double)NS;
}

int main() {
    printf("For the joint correlation of the 7-round DLN distinguisher on ChaCha256, we randomly generated 2^{6} keys and 2^{36} IVs\n");

    const uint64_t NK = ((uint64_t)1 << 6);  
    const uint64_t NIV = ((uint64_t)1 << 36);  

    std::mt19937 gen((unsigned int)time(NULL));


    const int    threads = THREADS_PER_BLOCK;
    const int    blocks = 4096;                       
    const uint64_t totalThreads = (uint64_t)blocks * threads;
 
    const uint64_t ivsPerThread = NIV / totalThreads; 

    // Device buffers.
    uint32_t* d_base = nullptr;
    unsigned long long* d_count = nullptr;
    CUDA_CHECK(cudaMalloc(&d_base, 12 * sizeof(uint32_t)));
    CUDA_CHECK(cudaMalloc(&d_count, sizeof(unsigned long long)));

    std::vector<double> cor(NK, 0.0);

    for (uint64_t iKey = 0; iKey < NK; ++iKey) {
        uint32_t base[12];
        base[0] = 0x61707865;
        base[1] = 0x3320646e;
        base[2] = 0x79622d32;
        base[3] = 0x6b206574;
        for (int i = 4; i < 12; ++i) base[i] = gen();

        CUDA_CHECK(cudaMemcpy(d_base, base, 12 * sizeof(uint32_t),
            cudaMemcpyHostToDevice));
        CUDA_CHECK(cudaMemset(d_count, 0, sizeof(unsigned long long)));

      
        unsigned long long seed =
            ((unsigned long long)gen() << 32) ^ (unsigned long long)gen() ^ iKey;

        countMatchesKernel << <blocks, threads >> > (d_base, ivsPerThread, seed, d_count);
        CUDA_CHECK(cudaGetLastError());
        CUDA_CHECK(cudaDeviceSynchronize());

        unsigned long long h_count = 0;
        CUDA_CHECK(cudaMemcpy(&h_count, d_count, sizeof(unsigned long long),
            cudaMemcpyDeviceToHost));

        cor[iKey] = 2.0 * ((double)h_count / (double)NIV) - 1.0;
        // printf("key %llu: cor = %g (2^%f)\n",
        //        (unsigned long long)iKey, cor[iKey], log2(fabs(cor[iKey])));
    }

    double res = GetAverageABS(cor.data(), NK);
    printf("Experimental results is %f(2^%f)\n", res, log2(fabs(res)));

    CUDA_CHECK(cudaFree(d_base));
    CUDA_CHECK(cudaFree(d_count));
    return 0;
}