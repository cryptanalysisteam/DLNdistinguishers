#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <random>
#include <algorithm>
using namespace std;

#define ROTL(a,b) (((a) << (b)) | ((a) >> (32 - (b))))
#define QR(a, b, c, d) (					\
        a += b,  d ^= a,  d = ROTL(d,16),	\
        c += d,  b ^= c,  b = ROTL(b,12),	\
        a += b,  d ^= a,  d = ROTL(d, 8),	\
        c += d,  b ^= c,  b = ROTL(b, 7))
#define HALF_QR1(a, b, c, d) (			\
                                        a += b,  d ^= a,  d = ROTL(d,16),	\
                                        c += d,  b ^= c,  b = ROTL(b,12))
#define HALF_QR2(a, b, c, d) (			\
                                        a += b,  d ^= a,  d = ROTL(d,8),	\
                                        c += d,  b ^= c,  b = ROTL(b,7))


#define GET_BIT(a,p) (((a)>>(p))&0x1)
mt19937 gen((unsigned int) time(NULL));



double GetAverageABS(double *array, uint64_t NS) {
	double sum = 0.0;
	for(uint64_t i = 0; i < NS; i++) {
		sum += fabs(array[i]);
	}
	return sum / NS;
}


int main() {
	printf("For the joint correlation of the 6-round DLN distinguisher on ChaCha256, we randomly generated 2^{10} keys and 2^{22} IVs\n");
	uint64_t NK;
	uint64_t NIV;
	NK=((uint64_t)1<<10);
	NIV=((uint64_t)1<<22);

	double res = 0.0;
	double cor[NK] = { 0 };

	for(uint64_t iKey = 0; iKey < NK; iKey++) {
		uint64_t ctr[NK] = { 0 };


		uint32_t X[16] = { 0 };
		X[0] = 0x61707865;
		X[1] = 0x3320646e;
		X[2] = 0x79622d32;
		X[3] = 0x6b206574;

		for(int i = 4; i < 12; i++) {
			X[i] = gen();
		}

		for(uint64_t iIV = 0; iIV < NIV; iIV++) {
			for(int i = 12; i < 16; i++) {
				X[i] = gen();
			}

			QR(X[0], X[4], X[ 8], X[12]);
			QR(X[1], X[5], X[ 9], X[13]);
			QR(X[2], X[6], X[10], X[14]);
			QR(X[3], X[7], X[11], X[15]);

			QR(X[0], X[5], X[10], X[15]);
			QR(X[1], X[6], X[11], X[12]);
			QR(X[2], X[7], X[ 8], X[13]);
			QR(X[3], X[4], X[ 9], X[14]);

			QR(X[0], X[4], X[ 8], X[12]);
			QR(X[1], X[5], X[ 9], X[13]);
			QR(X[2], X[6], X[10], X[14]);
			QR(X[3], X[7], X[11], X[15]);

			int input = 0;

			input = (X[3]>>0)&0x1 ^
			        (X[4]>>0)&0x1 ;

			QR(X[0], X[5], X[10], X[15]);
			QR(X[1], X[6], X[11], X[12]);
			QR(X[2], X[7], X[ 8], X[13]);
			QR(X[3], X[4], X[ 9], X[14]);

			QR(X[0], X[4], X[ 8], X[12]);
			QR(X[1], X[5], X[ 9], X[13]);
			QR(X[2], X[6], X[10], X[14]);
			QR(X[3], X[7], X[11], X[15]);

			QR(X[0], X[5], X[10], X[15]);
			QR(X[1], X[6], X[11], X[12]);
			QR(X[2], X[7], X[ 8], X[13]);
			QR(X[3], X[4], X[ 9], X[14]);


			int output = 0;

			output = (X[0]>>16)&0x1 ^ (X[0]>>0)&0x1 ^
			         (X[1]>>23)&0x1 ^ (X[1]>>12)&0x1 ^ (X[1]>>11)&0x1 ^ (X[1]>>7)&0x1 ^ (X[1]>>0)&0x1 ^
			         (X[2]>>24)&0x1 ^ (X[2]>>19)&0x1 ^ (X[2]>>18)&0x1 ^ (X[2]>>16)&0x1 ^ (X[2]>>8)&0x1 ^ (X[2]>>7)&0x1 ^ (X[2]>>0)&0x1 ^
			         (X[4]>>19)&0x1 ^ (X[4]>>13)&0x1 ^ (X[4]>>7)&0x1 ^
			         (X[5]>>7)&0x1 ^
			         (X[6]>>19)&0x1 ^ (X[6]>>14)&0x1 ^ (X[6]>>7)&0x1 ^
			         (X[7]>>26)&0x1 ^ (X[7]>>15)&0x1 ^ (X[7]>>7)&0x1 ^ (X[7]>>6)&0x1 ^
			         (X[8]>>31)&0x1 ^ (X[8]>>19)&0x1 ^ (X[8]>>8)&0x1 ^ (X[8]>>0)&0x1 ^
			         (X[9]>>26)&0x1 ^ (X[9]>>12)&0x1 ^ (X[9]>>6)&0x1 ^ (X[9]>>0)&0x1 ^
			         (X[10]>>0)&0x1 ^
			         (X[11]>>7)&0x1 ^
			         (X[12]>>31)&0x1 ^ (X[12]>>20)&0x1 ^ (X[12]>>19)&0x1 ^ (X[12]>>12)&0x1 ^ (X[12]>>0)&0x1 ^
			         (X[13]>>27)&0x1 ^ (X[13]>>26)&0x1 ^ (X[13]>>24)&0x1 ^ (X[13]>>15)&0x1 ^ (X[13]>>0)&0x1 ^
			         (X[14]>>26)&0x1 ^ (X[14]>>8)&0x1 ^
			         (X[15]>>24)&0x1 ^
			         ((((X[1]>>6)&0x1) ^ 0x1) & (((X[6]>>13)&0x1) ^ ((X[11]>>6)&0x1))) ^
			         (((((X[1]>>6)&0x1) ^ ((X[6]>>13)&0x1) ^ ((X[11]>>6)&0x1) ^ 0x1) & (((X[1]>>5)&0x1) ^ 0x1) & (((X[6]>>12)&0x1) ^ ((X[11]>>5)&0x1)))) ^
			         ((((X[11]>>11)&0x1) ^ 0x1) & ((X[12]>>11)&0x1)) ^
			         (((((X[11]>>11)&0x1) ^ ((X[12]>>11)&0x1) ^ 0x1) & (((X[11]>>10)&0x1) ^ 0x1) & ((X[12]>>10)&0x1))) ^
			         ((((X[2]>>7)&0x1) ^ 0x1) & (((X[7]>>14)&0x1) ^ ((X[8]>>7)&0x1))) ^
			         (((((X[2]>>7)&0x1) ^ ((X[7]>>14)&0x1) ^ ((X[8]>>7)&0x1) ^ 0x1) & (((X[2]>>6)&0x1) ^ 0x1) & (((X[7]>>13)&0x1) ^ ((X[8]>>6)&0x1)))) ^
			         ((((X[9]>>25)&0x1) ^ 0x1) & ((X[14]>>25)&0x1)) ^
			         (((((X[9]>>25)&0x1) ^ ((X[14]>>25)&0x1) ^ 0x1) & (((X[9]>>24)&0x1) ^ 0x1) & ((X[14]>>24)&0x1)));

			if(input == output) ctr[iKey]++;
		}

		cor[iKey] = 2.0*((double)ctr[iKey]/(double)NIV)-1.0;
	}
	res = GetAverageABS(cor,NK);

	printf("Experimental results is %f(2^%f)\n",res,log2(abs(res)));




	system("pause");

}
