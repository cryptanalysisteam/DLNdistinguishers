#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <random>
using namespace std;


#define ROTL(a,b) (((a) << (b)) | ((a) >> (32 - (b))))
#define QR(a, b, c, d) (					\
        a += b,  d ^= a,  d = ROTL(d,16),	\
        c += d,  b ^= c,  b = ROTL(b,12),	\
        a += b,  d ^= a,  d = ROTL(d, 8),	\
        c += d,  b ^= c,  b = ROTL(b, 7))
#define HALF_QR(a, b, c, d) (			\
                                        a += b,  d ^= a,  d = ROTL(d,16),	\
                                        c += d,  b ^= c,  b = ROTL(b,12))
#define HALF_QR2(a, b, c, d) (			\
                                        a += b,  d ^= a,  d = ROTL(d,8),	\
                                        c += d,  b ^= c,  b = ROTL(b,7))


#define GET_BIT(a,p) (((a)>>(p))&0x1)
mt19937 gen((unsigned int) time(NULL));

void BubbleSortABS(double *arr,int len) {
	double temp;
	int numSorted,indexToBubble;

	for(numSorted=0; numSorted<len-1; numSorted++)
		for(indexToBubble=0; indexToBubble<len-numSorted-1; indexToBubble++)
			if(fabs(arr[indexToBubble])<fabs(arr[indexToBubble+1])) {
				temp=arr[indexToBubble];
				arr[indexToBubble]=arr[indexToBubble+1];
				arr[indexToBubble+1]=temp;
			}
}

double GetMedianABS(double *array,uint64_t NS) {
	BubbleSortABS(array,NS);
	if(NS%2==1) return array[NS/2];
	else return (0.5*(fabs(array[NS/2])+fabs(array[NS/2-1])));
}



int main() {
	printf("For the 5-round DLN distinguisher DLN1, we randomly generated 2^{10} keys and 2^{26} IVs\n");
	uint64_t NIV;
	uint64_t NK;
	NK=((uint64_t)1<<10);
	NIV=((uint64_t)1<<26);
	uint64_t ctr[NK] ;
	memset(ctr,0,NK*sizeof(uint64_t));

	uint32_t X[16] = { 0 };
	uint32_t XX[16] = { 0 };
	uint32_t XXX[16] = { 0 };

	uint32_t ID[16] = { 0 };
	uint32_t OD[16] = { 0 };


	ID[ 0] = 0x00000004;
	ID[ 4] = 0x20020220;
	ID[ 8] = 0x40400400;
	ID[12] = 0x40000400;

	double res = 0.0;
	double cor[NK] = { 0 };

	int i = 0;

	for(uint64_t iKey = 0; iKey < NK; iKey++) {

		X[0] = 0x61707865;
		X[1] = 0x3320646e;
		X[2] = 0x79622d32;
		X[3] = 0x6b206574;

		for(i = 4; i < 12; i++) {
			X[i] = gen();
		}

		for(uint64_t iIV = 0; iIV < NIV; iIV++) {
			for(i = 12; i < 16; i++) {
				X[i] = gen();
			}

			QR(X[0], X[4], X[ 8], X[12]);
			QR(X[1], X[5], X[ 9], X[13]);
			QR(X[2], X[6], X[10], X[14]);
			QR(X[3], X[7], X[11], X[15]);

			for(i = 0; i < 16; i++) {
				XX[i] = X[i];
			}

			for(i = 0; i < 16; i++) {
				XXX[i] = XX[i] ^ ID[i];
			}

			QR(XX[0], XX[5], XX[10], XX[15]);
			QR(XX[1], XX[6], XX[11], XX[12]);
			QR(XX[2], XX[7], XX[ 8], XX[13]);
			QR(XX[3], XX[4], XX[ 9], XX[14]);

			QR(XX[0], XX[4], XX[ 8], XX[12]);
			QR(XX[1], XX[5], XX[ 9], XX[13]);
			QR(XX[2], XX[6], XX[10], XX[14]);
			QR(XX[3], XX[7], XX[11], XX[15]);

			QR(XX[0], XX[5], XX[10], XX[15]);
			QR(XX[1], XX[6], XX[11], XX[12]);
			QR(XX[2], XX[7], XX[ 8], XX[13]);
			QR(XX[3], XX[4], XX[ 9], XX[14]);

			QR(XX[0], XX[4], XX[ 8], XX[12]);
			QR(XX[1], XX[5], XX[ 9], XX[13]);
			QR(XX[2], XX[6], XX[10], XX[14]);
			QR(XX[3], XX[7], XX[11], XX[15]);


			QR(XXX[0], XXX[5], XXX[10], XXX[15]);
			QR(XXX[1], XXX[6], XXX[11], XXX[12]);
			QR(XXX[2], XXX[7], XXX[ 8], XXX[13]);
			QR(XXX[3], XXX[4], XXX[ 9], XXX[14]);

			QR(XXX[0], XXX[4], XXX[ 8], XXX[12]);
			QR(XXX[1], XXX[5], XXX[ 9], XXX[13]);
			QR(XXX[2], XXX[6], XXX[10], XXX[14]);
			QR(XXX[3], XXX[7], XXX[11], XXX[15]);

			QR(XXX[0], XXX[5], XXX[10], XXX[15]);
			QR(XXX[1], XXX[6], XXX[11], XXX[12]);
			QR(XXX[2], XXX[7], XXX[ 8], XXX[13]);
			QR(XXX[3], XXX[4], XXX[ 9], XXX[14]);

			QR(XXX[0], XXX[4], XXX[ 8], XXX[12]);
			QR(XXX[1], XXX[5], XXX[ 9], XXX[13]);
			QR(XXX[2], XXX[6], XXX[10], XXX[14]);
			QR(XXX[3], XXX[7], XXX[11], XXX[15]);


			int od =  ((XX[1] >> 0) & 0x1) ^
			          ((XX[5] >> 19) & 0x1) ^
			          ((XX[5] >> 7) & 0x1) ^
			          ((XX[9] >> 12) & 0x1) ^
			          ((XX[13] >> 0) & 0x1) ^
			          ((XX[6] >> 26) & 0x1) ^
			          ((XX[10] >> 19) & 0x1) ^
			          ((XX[10] >> 7) & 0x1) ^
			          ((XX[14] >> 7) & 0x1) ^
			          ((XX[11] >> 0) & 0x1) ^
			          ((XX[15] >> 8) & 0x1) ^
			          ((XX[15] >> 0) & 0x1) ^
			          ((XX[3] >> 0) & 0x1) ^
			          ((((XX[10] >> 6) & 0x1) ^ 0x1) & ((XX[14] >> 6) & 0x1)) ^
			          ((((XX[10] >> 6) & 0x1) ^ ((XX[14] >> 6) & 0x1) ^ 0x1) & (((XX[10] >> 5) & 0x1) ^ 0x1) & ((XX[14] >> 5) & 0x1)) ^
			          
			          ((XXX[1] >> 0) & 0x1) ^
			          ((XXX[5] >> 19) & 0x1) ^
			          ((XXX[5] >> 7) & 0x1) ^
			          ((XXX[9] >> 12) & 0x1) ^
			          ((XXX[13] >> 0) & 0x1) ^
			          ((XXX[6] >> 26) & 0x1) ^
			          ((XXX[10] >> 19) & 0x1) ^
			          ((XXX[10] >> 7) & 0x1) ^
			          ((XXX[14] >> 7) & 0x1) ^
			          ((XXX[11] >> 0) & 0x1) ^
			          ((XXX[15] >> 8) & 0x1) ^
			          ((XXX[15] >> 0) & 0x1) ^
			          ((XXX[3] >> 0) & 0x1) ^
			          ((((XXX[10] >> 6) & 0x1) ^ 0x1) & ((XXX[14] >> 6) & 0x1)) ^
			          ((((XXX[10] >> 6) & 0x1) ^ ((XXX[14] >> 6) & 0x1) ^ 0x1) & (((XXX[10] >> 5) & 0x1) ^ 0x1) & ((XXX[14] >> 5) & 0x1));
				


			if(od == 0) ctr[iKey]++;
		}

		cor[iKey] = 2.0*((double)ctr[iKey]/(double)NIV)-1.0;
	}
	res = GetMedianABS(cor,NK);
//	for(i = 0; i < NK; i++) {
//		printf("%d res = %f 2^%f\n",i,cor[i],log2(abs(cor[i])));
//	}
	printf("Experimental results is %f(2^%f)\n", res, log2(fabs(res)));

	system("pause");

}





