﻿#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <cuda_runtime.h>
#include <curand_kernel.h>

#define ROTL(a,b) (((a) << (b)) | ((a) >> (32 - (b))))
#define QR(a, b, c, d) ( \
                         b ^= ROTL(a + d, 7), \
                         c ^= ROTL(b + a, 9), \
                         d ^= ROTL(c + b, 13), \
                         a ^= ROTL(d + c, 18))

#define HALF_QR1(a, b, c, d) ( \
                               b ^= ROTL(a + d, 7), \
                               c ^= ROTL(b + a, 9))

#define HALF_QR2(a, b, c, d) ( \
                               d ^= ROTL(c + b, 13), \
                               a ^= ROTL(d + c, 18))

__device__ double atomicAddDouble(double* address, double val) {
    unsigned long long int* address_as_ull = (unsigned long long int*)address;
    unsigned long long int old = *address_as_ull, assumed;
    do {
        assumed = old;
        old = atomicCAS(address_as_ull, assumed,
            __double_as_longlong(val + __longlong_as_double(assumed)));
    } while (assumed != old);
    return __longlong_as_double(old);
}

__global__ void initRNG(curandState* state, unsigned long long seed, uint64_t n) {
    uint64_t idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        curand_init(seed, idx, 0, &state[idx]);
    }
}

__global__ void computeCorrelations(curandState* rngStates,
    uint32_t* keys,
    uint64_t* counters,
    uint64_t NK,
    uint64_t NIV,
    uint64_t ivsPerThread) {
    uint64_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    uint64_t totalThreads = gridDim.x * blockDim.x;

    // Each thread processes multiple keys
    for (uint64_t iKey = 0; iKey < NK; iKey++) {
        uint64_t localCounter = 0;

        // Load key for this iteration
        uint32_t X[16];
        X[0] = 0x61707865;
        X[5] = 0x3320646e;
        X[10] = 0x79622d32;
        X[15] = 0x6b206574;

        // Load key values
        for (int i = 1; i < 5; i++) {
            X[i] = keys[iKey * 8 + (i - 1)];
        }
        for (int i = 11; i < 15; i++) {
            X[i] = keys[iKey * 8 + (i - 7)];
        }

        curandState localState = rngStates[tid];

        // Each thread processes a subset of IVs
        for (uint64_t iIV = tid; iIV < NIV; iIV += totalThreads) {
            // Generate random IV
            for (int i = 6; i < 10; i++) {
                X[i] = curand(&localState);
            }

            int input = 0;
            int output = 0;

       
            QR(X[0], X[4], X[8], X[12]);
            QR(X[5], X[9], X[13], X[1]);
            QR(X[10], X[14], X[2], X[6]);
            QR(X[15], X[3], X[7], X[11]);

            QR(X[0], X[1], X[2], X[3]);
            QR(X[5], X[6], X[7], X[4]);
            QR(X[10], X[11], X[8], X[9]);
            QR(X[15], X[12], X[13], X[14]);

        
            QR(X[0], X[4], X[8], X[12]);
            QR(X[5], X[9], X[13], X[1]);
            QR(X[10], X[14], X[2], X[6]);
            QR(X[15], X[3], X[7], X[11]);

            QR(X[0], X[1], X[2], X[3]);
            QR(X[5], X[6], X[7], X[4]);
            QR(X[10], X[11], X[8], X[9]);
            QR(X[15], X[12], X[13], X[14]);

      
            QR(X[0], X[4], X[8], X[12]);
            QR(X[5], X[9], X[13], X[1]);
            QR(X[10], X[14], X[2], X[6]);
            QR(X[15], X[3], X[7], X[11]);

            input = (X[4] >> 7) & 0x1;

            QR(X[0], X[1], X[2], X[3]);
            QR(X[5], X[6], X[7], X[4]);
            QR(X[10], X[11], X[8], X[9]);
            QR(X[15], X[12], X[13], X[14]);

          
            QR(X[0], X[4], X[8], X[12]);
            QR(X[5], X[9], X[13], X[1]);
            QR(X[10], X[14], X[2], X[6]);
            QR(X[15], X[3], X[7], X[11]);

            HALF_QR1(X[0], X[1], X[2], X[3]);
            HALF_QR1(X[5], X[6], X[7], X[4]);
            HALF_QR1(X[10], X[11], X[8], X[9]);
            HALF_QR1(X[15], X[12], X[13], X[14]);

            output =
                (X[0] >> 4) & 0x1 ^ (X[0] >> 0) & 0x1 ^
                (X[1] >> 4) & 0x1 ^ (X[1] >> 3) & 0x1 ^
                (X[2] >> 13) & 0x1 ^
                (X[3] >> 17) & 0x1 ^
                (X[4] >> 7) & 0x1 ^
                (X[5] >> 22) & 0x1 ^ (X[5] >> 21) & 0x1 ^ (X[5] >> 19) & 0x1 ^
                (X[6] >> 26) & 0x1 ^ (X[6] >> 25) & 0x1 ^ (X[6] >> 22) & 0x1 ^ (X[6] >> 17) & 0x1 ^ (X[6] >> 16) & 0x1 ^
                (X[7] >> 31) & 0x1 ^ (X[7] >> 26) & 0x1 ^
                (X[8] >> 19) & 0x1 ^ (X[8] >> 14) & 0x1 ^
                (X[9] >> 24) & 0x1 ^
                (X[10] >> 24) & 0x1 ^ (X[10] >> 23) & 0x1 ^ (X[10] >> 10) & 0x1 ^ (X[10] >> 9) & 0x1 ^ (X[10] >> 5) & 0x1 ^ (X[10] >> 4) & 0x1 ^
                (X[11] >> 31) & 0x1 ^ (X[11] >> 10) & 0x1 ^ (X[11] >> 5) & 0x1 ^
                (X[12] >> 14) & 0x1 ^ (X[12] >> 13) & 0x1 ^ (X[12] >> 0) & 0x1 ^
                (X[14] >> 25) & 0x1 ^ (X[14] >> 13) & 0x1 ^ (X[14] >> 7) & 0x1 ^
                (X[15] >> 25) & 0x1 ^ (X[15] >> 24) & 0x1 ^ (X[15] >> 17) & 0x1 ^ (X[15] >> 16) & 0x1 ^ (X[15] >> 7) & 0x1;

            if (input == output) localCounter++;
        }

        rngStates[tid] = localState;

        // Atomic add to global counter for this key
        atomicAdd(&counters[iKey], localCounter);
    }
}

double GetAverageABS(double* array, uint64_t NS) {
    double sum = 0.0;
    for (uint64_t i = 0; i < NS; i++) {
        sum += fabs(array[i]);
    }
    return sum / NS;
}

int main() {
    printf("For the first part of Computational Result 11, we randomly generated 2^{6} keys and 2^{38} IVs\n");

    uint64_t NK = ((uint64_t)1 << 6);
    uint64_t NIV = ((uint64_t)1 << 38);

    // Generate keys on CPU
    uint32_t* h_keys = new uint32_t[NK * 8];
    srand(time(NULL));
    for (uint64_t i = 0; i < NK * 8; i++) {
        h_keys[i] = rand();
    }

    // Allocate device memory
    uint32_t* d_keys;
    uint64_t* d_counters;
    cudaMalloc(&d_keys, NK * 8 * sizeof(uint32_t));
    cudaMalloc(&d_counters, NK * sizeof(uint64_t));

    cudaMemcpy(d_keys, h_keys, NK * 8 * sizeof(uint32_t), cudaMemcpyHostToDevice);
    cudaMemset(d_counters, 0, NK * sizeof(uint64_t));

    // Setup RNG states
    int threadsPerBlock = 256;
    int numBlocks = 1024;
    uint64_t totalThreads = threadsPerBlock * numBlocks;

    curandState* d_rngStates;
    cudaMalloc(&d_rngStates, totalThreads * sizeof(curandState));

    initRNG << <numBlocks, threadsPerBlock >> > (d_rngStates, time(NULL), totalThreads);
    cudaDeviceSynchronize();

    // Launch kernel
    printf("Launching kernel with %d blocks and %d threads per block", numBlocks, threadsPerBlock);
        computeCorrelations << <numBlocks, threadsPerBlock >> > (d_rngStates, d_keys, d_counters, NK, NIV, NIV / totalThreads);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("CUDA error: %s\n", cudaGetErrorString(err));
        return 1;
    }

    cudaDeviceSynchronize();

    // Copy results back
    uint64_t* h_counters = new uint64_t[NK];
    cudaMemcpy(h_counters, d_counters, NK * sizeof(uint64_t), cudaMemcpyDeviceToHost);

    // Compute correlations
    double* cor = new double[NK];
    for (uint64_t iKey = 0; iKey < NK; iKey++) {
        cor[iKey] = 2.0 * ((double)h_counters[iKey] / (double)NIV) - 1.0;
        printf("%f(2^%f)\n", cor[iKey], log2(fabs(cor[iKey])));
    }

    double res = GetAverageABS(cor, NK);
    printf("The first part of Computational Result 11 is %f(2^%f) ", res, log2(fabs(res)));

        // Cleanup
        delete[] h_keys;
    delete[] h_counters;
    delete[] cor;
    cudaFree(d_keys);
    cudaFree(d_counters);
    cudaFree(d_rngStates);

    return 0;
}
