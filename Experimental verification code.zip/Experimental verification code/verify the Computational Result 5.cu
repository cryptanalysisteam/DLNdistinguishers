﻿#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#include <random>
#include <cuda_runtime.h>


#define ROTL(a,b) (((a) << (b)) | ((a) >> (32 - (b))))
#define QR(a, b, c, d) (                    \
        a += b,  d ^= a,  d = ROTL(d,16),   \
        c += d,  b ^= c,  b = ROTL(b,12),   \
        a += b,  d ^= a,  d = ROTL(d, 8),   \
        c += d,  b ^= c,  b = ROTL(b, 7))


typedef struct {
    uint64_t s[2];
} xorshift128plus_state;

__device__ __forceinline__ uint64_t xorshift128plus(xorshift128plus_state* state) {
    uint64_t x = state->s[0];
    uint64_t const y = state->s[1];
    state->s[0] = y;
    x ^= x << 23;
    state->s[1] = x ^ y ^ (x >> 17) ^ (y >> 26);
    return state->s[1] + y;
}

__device__ __forceinline__ void init_xorshift128plus(xorshift128plus_state* state, uint64_t seed) {
    state->s[0] = seed ^ 0x6A09E667F3BCC909ULL;
    state->s[1] = seed ^ 0xBB67AE8584CAA73BULL;
    for (int i = 0; i < 10; i++) {
        xorshift128plus(state);
    }
}


__global__ void distinguisher_kernel(const uint32_t* __restrict__ d_base,
    uint64_t iter_per_thread,
    uint64_t time_seed,
    uint64_t* d_global_ctr) {
    uint64_t tid = blockIdx.x * blockDim.x + threadIdx.x;

    xorshift128plus_state rng;
    uint64_t seed = time_seed ^ (tid * 0x9E3779B97F4A7C15ULL);
    init_xorshift128plus(&rng, seed);

    
    uint32_t base[12];
#pragma unroll
    for (int j = 0; j < 12; j++) base[j] = d_base[j];

    uint32_t X[16];
    uint64_t local_ctr = 0;

    for (uint64_t i = 0; i < iter_per_thread; i++) {
#pragma unroll
        for (int j = 0; j < 12; j++) X[j] = base[j];

       
        uint64_t r0 = xorshift128plus(&rng);
        uint64_t r1 = xorshift128plus(&rng);
        X[12] = (uint32_t)r0;
        X[13] = (uint32_t)(r0 >> 32);
        X[14] = (uint32_t)r1;
        X[15] = (uint32_t)(r1 >> 32);

        QR(X[0], X[4], X[8], X[12]); QR(X[1], X[5], X[9], X[13]);
        QR(X[2], X[6], X[10], X[14]); QR(X[3], X[7], X[11], X[15]);

        QR(X[0], X[5], X[10], X[15]); QR(X[1], X[6], X[11], X[12]);
        QR(X[2], X[7], X[8], X[13]); QR(X[3], X[4], X[9], X[14]);

        QR(X[0], X[4], X[8], X[12]); QR(X[1], X[5], X[9], X[13]);
        QR(X[2], X[6], X[10], X[14]); QR(X[3], X[7], X[11], X[15]);

        QR(X[0], X[5], X[10], X[15]); QR(X[1], X[6], X[11], X[12]);
        QR(X[2], X[7], X[8], X[13]); QR(X[3], X[4], X[9], X[14]);

        QR(X[0], X[4], X[8], X[12]); QR(X[1], X[5], X[9], X[13]);
        QR(X[2], X[6], X[10], X[14]); QR(X[3], X[7], X[11], X[15]);

        int input = ((X[2] >> 0) & 0x1) ^ ((X[6] >> 19) & 0x1) ^ ((X[6] >> 7) & 0x1) ^
            ((X[10] >> 12) & 0x1) ^ ((X[14] >> 0) & 0x1);

        QR(X[0], X[5], X[10], X[15]); QR(X[1], X[6], X[11], X[12]);
        QR(X[2], X[7], X[8], X[13]); QR(X[3], X[4], X[9], X[14]);

        QR(X[0], X[4], X[8], X[12]); QR(X[1], X[5], X[9], X[13]);
        QR(X[2], X[6], X[10], X[14]); QR(X[3], X[7], X[11], X[15]);

        int output =
            ((X[0] >> 23) & 0x1) ^ ((X[0] >> 19) & 0x1) ^ ((X[0] >> 7) & 0x1) ^ ((X[0] >> 3) & 0x1) ^ ((X[0] >> 2) & 0x1) ^
            ((X[1] >> 16) & 0x1) ^
            ((X[2] >> 24) & 0x1) ^ ((X[2] >> 23) & 0x1) ^ ((X[2] >> 12) & 0x1) ^ ((X[2] >> 8) & 0x1) ^ ((X[2] >> 0) & 0x1) ^
            ((X[3] >> 31) & 0x1) ^ ((X[3] >> 28) & 0x1) ^ ((X[3] >> 20) & 0x1) ^ ((X[3] >> 16) & 0x1) ^ ((X[3] >> 12) & 0x1) ^
            ((X[3] >> 11) & 0x1) ^ ((X[3] >> 7) & 0x1) ^ ((X[3] >> 4) & 0x1) ^ ((X[3] >> 3) & 0x1) ^ ((X[3] >> 0) & 0x1) ^
            ((X[4] >> 31) & 0x1) ^ ((X[4] >> 19) & 0x1) ^ ((X[4] >> 14) & 0x1) ^ ((X[4] >> 13) & 0x1) ^
            ((X[5] >> 7) & 0x1) ^
            ((X[6] >> 31) & 0x1) ^ ((X[6] >> 25) & 0x1) ^ ((X[6] >> 19) & 0x1) ^ ((X[6] >> 13) & 0x1) ^ ((X[6] >> 7) & 0x1) ^
            ((X[7] >> 27) & 0x1) ^ ((X[7] >> 26) & 0x1) ^ ((X[7] >> 23) & 0x1) ^ ((X[7] >> 7) & 0x1) ^ ((X[7] >> 6) & 0x1) ^ ((X[7] >> 3) & 0x1) ^
            ((X[8] >> 24) & 0x1) ^ ((X[8] >> 12) & 0x1) ^
            ((X[10] >> 26) & 0x1) ^ ((X[10] >> 24) & 0x1) ^ ((X[10] >> 18) & 0x1) ^
            ((X[11] >> 28) & 0x1) ^ ((X[11] >> 20) & 0x1) ^
            ((X[12] >> 31) & 0x1) ^ ((X[12] >> 20) & 0x1) ^ ((X[12] >> 19) & 0x1) ^ ((X[12] >> 11) & 0x1) ^ ((X[12] >> 10) & 0x1) ^ ((X[12] >> 7) & 0x1) ^
            ((X[13] >> 24) & 0x1) ^ ((X[13] >> 8) & 0x1) ^ ((X[13] >> 0) & 0x1) ^
            ((X[14] >> 26) & 0x1) ^ ((X[14] >> 25) & 0x1) ^ ((X[14] >> 20) & 0x1) ^ ((X[14] >> 16) & 0x1) ^
            ((X[14] >> 12) & 0x1) ^ ((X[14] >> 11) & 0x1) ^ ((X[14] >> 6) & 0x1) ^ ((X[14] >> 5) & 0x1) ^ ((X[14] >> 0) & 0x1) ^
            ((X[15] >> 31) & 0x1) ^ ((X[15] >> 19) & 0x1) ^ ((X[15] >> 18) & 0x1) ^ ((X[15] >> 16) & 0x1) ^
            ((X[15] >> 12) & 0x1) ^ ((X[15] >> 11) & 0x1) ^ ((X[15] >> 7) & 0x1) ^ ((X[15] >> 4) & 0x1) ^ ((X[15] >> 0) & 0x1);

        if (input == output) local_ctr++;
    }

    __shared__ uint64_t s_counter;
    if (threadIdx.x == 0) s_counter = 0;
    __syncthreads();
    atomicAdd(&s_counter, local_ctr);
    __syncthreads();
    if (threadIdx.x == 0) {
        atomicAdd(d_global_ctr, s_counter);
    }
}


static double GetAverageABS(const double* array, uint64_t NS) {
    double sum = 0.0;
    for (uint64_t i = 0; i < NS; i++) sum += fabs(array[i]);
    return sum / (double)NS;
}


int main() {
    printf("For the Computational Result 5, we randomly generated 2^{4} keys and 2^{48} IVs\n");

    const uint64_t NK = 1ULL << 4;    
    const uint64_t NIV = 1ULL << 48;   

    const int BLOCK_DIM = 256;
    const int GRID_DIM = 4096;
    uint64_t total_threads = (uint64_t)BLOCK_DIM * GRID_DIM;   
    uint64_t iter_per_thread = NIV / total_threads;             

    printf("GPU Configuration: %d blocks x %d threads = %llu threads\n",
        GRID_DIM, BLOCK_DIM, (unsigned long long)total_threads);
    printf("Each thread processes %llu iterations (per key)\n",
        (unsigned long long)iter_per_thread);

    std::mt19937 gen((unsigned int)time(NULL));

    uint32_t* d_base = NULL;
    uint64_t* d_counter = NULL;
    cudaMalloc(&d_base, 12 * sizeof(uint32_t));
    cudaMalloc(&d_counter, sizeof(uint64_t));

    double* cor = (double*)malloc(NK * sizeof(double));

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);
    cudaEventRecord(start);

    for (uint64_t iKey = 0; iKey < NK; iKey++) {
    
        uint32_t base[12];
        base[0] = 0x61707865; base[1] = 0x3320646e;
        base[2] = 0x79622d32; base[3] = 0x6b206574;
        for (int j = 4; j < 12; j++) base[j] = gen();

        cudaMemcpy(d_base, base, 12 * sizeof(uint32_t), cudaMemcpyHostToDevice);
        cudaMemset(d_counter, 0, sizeof(uint64_t));

     
        uint64_t time_seed = ((uint64_t)gen() << 32) ^ (uint64_t)gen() ^ iKey;

        distinguisher_kernel << <GRID_DIM, BLOCK_DIM >> > (d_base, iter_per_thread,
            time_seed, d_counter);
        cudaDeviceSynchronize();

        uint64_t h_counter = 0;
        cudaMemcpy(&h_counter, d_counter, sizeof(uint64_t), cudaMemcpyDeviceToHost);

        cor[iKey] = 2.0 * ((double)h_counter / (double)NIV) - 1.0;
      //  printf("key %llu: cor = %g (2^%f)\n",
       //     (unsigned long long)iKey, cor[iKey], log2(fabs(cor[iKey])));
    }

    cudaEventRecord(stop);
    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("Total execution time: %.4f seconds\n", ms / 1000.0f);

    double res = GetAverageABS(cor, NK);
    printf("Experimental result is p = %f(2^%f)\n", res, log2(fabs(res)));

    free(cor);
    cudaFree(d_base);
    cudaFree(d_counter);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}