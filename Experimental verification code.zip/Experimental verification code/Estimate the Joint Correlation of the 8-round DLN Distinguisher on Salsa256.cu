﻿#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <random>
#include <cuda_runtime.h>
#include <curand_kernel.h>

#define ROTL(a,b) (((a) << (b)) | ((a) >> (32 - (b))))
#define QR(a, b, c, d) ( \
                         b ^= ROTL(a + d, 7), \
                         c ^= ROTL(b + a, 9), \
                         d ^= ROTL(c + b, 13), \
                         a ^= ROTL(d + c, 18))

#define THREADS_PER_BLOCK 256

__global__ void chacha20_correlation_kernel(
    const uint32_t* __restrict__ d_base,
    uint64_t iter_per_thread,
    unsigned long long seed,
    uint64_t* __restrict__ d_global_ctr
) {
    __shared__ uint64_t sdata[THREADS_PER_BLOCK];

    const unsigned int tid = threadIdx.x;
    const uint64_t gid = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;

    uint32_t base[16];
#pragma unroll
    for (int i = 0; i < 16; i++) base[i] = d_base[i];

    curandStatePhilox4_32_10_t st;
    curand_init(seed, gid, 0, &st);

    uint64_t local_ctr = 0;

    for (uint64_t k = 0; k < iter_per_thread; k++) {
        uint32_t X[16];
#pragma unroll
        for (int i = 0; i < 16; i++) X[i] = base[i];

        uint4 r = curand4(&st);
        X[6] = r.x;
        X[7] = r.y;
        X[8] = r.z;
        X[9] = r.w;

        int input = 0;
        int output = 0;

        QR(X[0], X[4], X[8], X[12]);
        QR(X[5], X[9], X[13], X[1]);
        QR(X[10], X[14], X[2], X[6]);
        QR(X[15], X[3], X[7], X[11]);

        QR(X[0], X[1], X[2], X[3]);
        QR(X[5], X[6], X[7], X[4]);
        QR(X[10], X[11], X[8], X[9]);
        QR(X[15], X[12], X[13], X[14]);

        QR(X[0], X[4], X[8], X[12]);
        QR(X[5], X[9], X[13], X[1]);
        QR(X[10], X[14], X[2], X[6]);
        QR(X[15], X[3], X[7], X[11]);

        QR(X[0], X[1], X[2], X[3]);
        QR(X[5], X[6], X[7], X[4]);
        QR(X[10], X[11], X[8], X[9]);
        QR(X[15], X[12], X[13], X[14]);

        QR(X[0], X[4], X[8], X[12]);
        QR(X[5], X[9], X[13], X[1]);
        QR(X[10], X[14], X[2], X[6]);
        QR(X[15], X[3], X[7], X[11]);

        input = ((X[4] >> 7) & 0x1);

        QR(X[0], X[1], X[2], X[3]);
        QR(X[5], X[6], X[7], X[4]);
        QR(X[10], X[11], X[8], X[9]);
        QR(X[15], X[12], X[13], X[14]);

        QR(X[0], X[4], X[8], X[12]);
        QR(X[5], X[9], X[13], X[1]);
        QR(X[10], X[14], X[2], X[6]);
        QR(X[15], X[3], X[7], X[11]);

        QR(X[0], X[1], X[2], X[3]);
        QR(X[5], X[6], X[7], X[4]);
        QR(X[10], X[11], X[8], X[9]);
        QR(X[15], X[12], X[13], X[14]);

        output =
            ((X[0] >> 4) & 0x1) ^ ((X[0] >> 0) & 0x1) ^
            ((X[2] >> 18) & 0x1) ^ ((X[2] >> 14) & 0x1) ^ ((X[2] >> 13) & 0x1) ^ ((X[2] >> 12) & 0x1) ^ ((X[2] >> 4) & 0x1) ^
            ((X[3] >> 18) & 0x1) ^ ((X[3] >> 17) & 0x1) ^ ((X[3] >> 14) & 0x1) ^
            ((X[4] >> 31) & 0x1) ^ ((X[4] >> 4) & 0x1) ^ ((X[4] >> 7) & 0x1) ^ ((X[4] >> 1) & 0x1) ^
            ((X[5] >> 22) & 0x1) ^ ((X[5] >> 19) & 0x1) ^ ((X[5] >> 17) & 0x1) ^
            ((X[6] >> 22) & 0x1) ^ ((X[6] >> 21) & 0x1) ^ ((X[6] >> 17) & 0x1) ^
            ((X[7] >> 25) & 0x1) ^ ((X[7] >> 4) & 0x1) ^ ((X[7] >> 1) & 0x1) ^
            ((X[8] >> 24) & 0x1) ^ ((X[8] >> 14) & 0x1) ^ ((X[8] >> 11) & 0x1) ^ ((X[8] >> 6) & 0x1) ^
            ((X[9] >> 19) & 0x1) ^ ((X[9] >> 6) & 0x1) ^
            ((X[10] >> 24) & 0x1) ^ ((X[10] >> 10) & 0x1) ^ ((X[10] >> 5) & 0x1) ^
            ((X[11] >> 31) & 0x1) ^ ((X[11] >> 30) & 0x1) ^ ((X[11] >> 11) & 0x1) ^ ((X[11] >> 10) & 0x1) ^
            ((X[11] >> 9) & 0x1) ^ ((X[11] >> 5) & 0x1) ^ ((X[11] >> 4) & 0x1) ^
            ((X[12] >> 26) & 0x1) ^ ((X[12] >> 14) & 0x1) ^ ((X[12] >> 13) & 0x1) ^ ((X[12] >> 12) & 0x1) ^
            ((X[13] >> 31) & 0x1) ^ ((X[13] >> 26) & 0x1) ^ ((X[13] >> 21) & 0x1) ^ ((X[13] >> 12) & 0x1) ^
            ((X[13] >> 7) & 0x1) ^ ((X[13] >> 6) & 0x1) ^ ((X[13] >> 0) & 0x1) ^
            ((X[14] >> 31) & 0x1) ^ ((X[14] >> 25) & 0x1) ^ ((X[14] >> 21) & 0x1) ^ ((X[14] >> 13) & 0x1) ^ ((X[14] >> 6) & 0x1) ^
            ((X[15] >> 25) & 0x1) ^ ((X[15] >> 24) & 0x1) ^ ((X[15] >> 17) & 0x1) ^ ((X[15] >> 7) & 0x1) ^
            (((X[2] >> 3) & 0x1) & ((X[1] >> 3) & 0x1)) ^
            ((((X[2] >> 3) & 0x1) ^ ((X[1] >> 3) & 0x1)) & ((X[2] >> 2) & 0x1) & ((X[1] >> 2) & 0x1)) ^
            (((X[2] >> 17) & 0x1) & ((X[3] >> 17) & 0x1)) ^
            ((((X[2] >> 17) & 0x1) ^ ((X[3] >> 17) & 0x1)) & ((X[2] >> 16) & 0x1) & ((X[3] >> 16) & 0x1)) ^
            (((X[2] >> 13) & 0x1) & ((X[3] >> 13) & 0x1)) ^
            ((((X[2] >> 13) & 0x1) ^ ((X[3] >> 13) & 0x1)) & ((X[2] >> 12) & 0x1) & ((X[3] >> 12) & 0x1)) ^
            (((X[6] >> 25) & 0x1) & ((X[7] >> 25) & 0x1)) ^
            ((((X[6] >> 25) & 0x1) ^ ((X[7] >> 25) & 0x1)) & ((X[6] >> 24) & 0x1) & ((X[7] >> 24) & 0x1)) ^
            (((X[7] >> 0) & 0x1) & ((X[4] >> 0) & 0x1)) ^
            (((X[7] >> 30) & 0x1) & ((X[4] >> 30) & 0x1)) ^
            ((((X[7] >> 30) & 0x1) ^ ((X[4] >> 30) & 0x1)) & ((X[7] >> 29) & 0x1) & ((X[4] >> 29) & 0x1)) ^
            (((X[7] >> 3) & 0x1) & ((X[4] >> 3) & 0x1)) ^
            ((((X[7] >> 3) & 0x1) ^ ((X[4] >> 3) & 0x1)) & ((X[7] >> 2) & 0x1) & ((X[4] >> 2) & 0x1)) ^
            (((X[8] >> 23) & 0x1) & ((X[9] >> 23) & 0x1)) ^
            ((((X[8] >> 23) & 0x1) ^ ((X[9] >> 23) & 0x1)) & ((X[8] >> 22) & 0x1) & ((X[9] >> 22) & 0x1)) ^
            (((X[8] >> 18) & 0x1) & ((X[9] >> 18) & 0x1)) ^
            ((((X[8] >> 18) & 0x1) ^ ((X[9] >> 18) & 0x1)) & ((X[8] >> 17) & 0x1) & ((X[9] >> 17) & 0x1)) ^
            (((X[8] >> 5) & 0x1) & ((X[9] >> 5) & 0x1)) ^
            ((((X[8] >> 5) & 0x1) ^ ((X[9] >> 5) & 0x1)) & ((X[8] >> 4) & 0x1) & ((X[9] >> 4) & 0x1)) ^
            (((X[11] >> 10) & 0x1) & ((X[8] >> 10) & 0x1)) ^
            ((((X[11] >> 10) & 0x1) ^ ((X[8] >> 10) & 0x1)) & ((X[11] >> 9) & 0x1) & ((X[8] >> 9) & 0x1)) ^
            (((X[12] >> 25) & 0x1) & ((X[13] >> 25) & 0x1)) ^
            ((((X[12] >> 25) & 0x1) ^ ((X[13] >> 25) & 0x1)) & ((X[12] >> 24) & 0x1) & ((X[13] >> 24) & 0x1)) ^
            (((X[12] >> 11) & 0x1) & ((X[13] >> 11) & 0x1)) ^
            ((((X[12] >> 11) & 0x1) ^ ((X[13] >> 11) & 0x1)) & ((X[12] >> 10) & 0x1) & ((X[13] >> 10) & 0x1)) ^
            (((X[13] >> 30) & 0x1) & ((X[14] >> 30) & 0x1)) ^
            ((((X[13] >> 30) & 0x1) ^ ((X[14] >> 30) & 0x1)) & ((X[13] >> 29) & 0x1) & ((X[14] >> 29) & 0x1)) ^
            (((X[13] >> 20) & 0x1) & ((X[14] >> 20) & 0x1)) ^
            ((((X[13] >> 20) & 0x1) ^ ((X[14] >> 20) & 0x1)) & ((X[13] >> 19) & 0x1) & ((X[14] >> 19) & 0x1)) ^
            (((X[13] >> 6) & 0x1) & ((X[14] >> 6) & 0x1)) ^
            ((((X[13] >> 6) & 0x1) ^ ((X[14] >> 6) & 0x1) ^ 0x1) & ((X[13] >> 5) & 0x1) & ((X[14] >> 5) & 0x1));

        if (input == output) local_ctr++;
    }

    sdata[tid] = local_ctr;
    __syncthreads();

    for (unsigned int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (tid < s) sdata[tid] += sdata[tid + s];
        __syncthreads();
    }

    if (tid == 0) atomicAdd(d_global_ctr, sdata[0]);
}

double GetAverageABS(double* array, uint64_t NS) {
    double sum = 0.0;
    for (uint64_t i = 0; i < NS; i++) {
        sum += fabs(array[i]);
    }
    return sum / (double)NS;
}

int main() {
    printf("For the joint correlation of the 8-round DLN distinguisher on Salsa256, we randomly generated 2^{4} keys and 2^{44} IVs\n");


    const uint64_t NK = (uint64_t)1 << 4;
    const uint64_t NIV = (uint64_t)1 << 44;

    const int BLOCK_DIM = THREADS_PER_BLOCK;
    const int GRID_DIM = 4096;
    uint64_t total_threads = (uint64_t)BLOCK_DIM * GRID_DIM;
    uint64_t iter_per_thread = NIV / total_threads;

    printf("GPU Configuration: %d blocks x %d threads = %llu threads\n",
        GRID_DIM, BLOCK_DIM, (unsigned long long)total_threads);
    printf("Each thread processes %llu iterations (per key)\n",
        (unsigned long long)iter_per_thread);

    std::mt19937 gen((unsigned int)time(NULL));

    uint32_t* d_base = NULL;
    uint64_t* d_counter = NULL;
    cudaMalloc(&d_base, 16 * sizeof(uint32_t));
    cudaMalloc(&d_counter, sizeof(uint64_t));

    double* cor = (double*)malloc(NK * sizeof(double));

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);
    cudaEventRecord(start);

    for (uint64_t iKey = 0; iKey < NK; iKey++) {
        uint32_t base[16] = { 0 };
        base[0] = 0x61707865;
        base[5] = 0x3320646e;
        base[10] = 0x79622d32;
        base[15] = 0x6b206574;

        for (int i = 1; i < 5; i++) base[i] = gen();
        for (int i = 11; i < 15; i++) base[i] = gen();

        cudaMemcpy(d_base, base, 16 * sizeof(uint32_t), cudaMemcpyHostToDevice);
        cudaMemset(d_counter, 0, sizeof(uint64_t));

        unsigned long long seed =
            ((unsigned long long)gen() << 32) ^ (unsigned long long)gen() ^ iKey;

        chacha20_correlation_kernel << <GRID_DIM, BLOCK_DIM >> > (
            d_base, iter_per_thread, seed, d_counter);
        cudaDeviceSynchronize();

        uint64_t h_counter = 0;
        cudaMemcpy(&h_counter, d_counter, sizeof(uint64_t), cudaMemcpyDeviceToHost);

        cor[iKey] = 2.0 * ((double)h_counter / (double)NIV) - 1.0;
        printf("Key %llu: ctr = %llu, cor = %f (2^%f)\n",
            (unsigned long long)iKey, (unsigned long long)h_counter,
            cor[iKey], log2(fabs(cor[iKey])));
    }

    cudaEventRecord(stop);
    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("Total execution time: %.4f seconds\n", ms / 1000.0f);

    double res = GetAverageABS(cor, NK);
    printf("Experimental results is %f(2^%f)\n", res, log2(fabs(res)));

    free(cor);
    cudaFree(d_base);
    cudaFree(d_counter);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}